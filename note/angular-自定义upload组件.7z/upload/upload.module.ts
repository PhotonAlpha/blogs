import { NgModule, ModuleWithProviders } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { CqUploadComponent } from './upload.component';
import { CqUploadDraggerComponent } from './upload.dragger.component';
import { CqUploadListComponent } from './upload.list.component';
import { CqUploadRequest } from './upload.request';
import { MatProgressBarModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';


@NgModule({
  declarations: [
    CqUploadComponent, CqUploadListComponent, CqUploadDraggerComponent
  ],
  exports: [CqUploadComponent],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,

    MatProgressBarModule,
    FlexLayoutModule
  ],
  entryComponents: [CqUploadComponent],
  providers: [
    CqUploadRequest
  ]
})
export class CqUploadModule {
  static forRoot(): ModuleWithProviders {
    return { ngModule: CqUploadModule, providers: [CqUploadRequest] };
  }
}
