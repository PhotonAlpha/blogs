import {
  Component, ContentChild, ElementRef, Input, OnChanges, OnInit, SimpleChange, SimpleChanges, TemplateRef,
  ViewChild,
} from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpResponse } from '@angular/common/http';
import { CqUploadProps } from './upload.props';
import { CqUploadRequest } from './upload.request';
import { CommonFile, UploadFile } from './upload.interface';

@Component({
  selector: 'cq-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.css', './upload.component.scss']
})
export class CqUploadComponent extends CqUploadProps implements OnInit, OnChanges {

  /**
   * status: success -> success description
   * status: failure -> failure description
   * status: oversize -> oversize description
   */
  @ContentChild('trigger', { static: false }) trigger: TemplateRef<any>;
  @ContentChild('dragger', { static: false }) dragger: TemplateRef<any>;
  @ContentChild('tip', { static: false }) tip: TemplateRef<any>;
  @ViewChild('input', { static: false }) input: ElementRef;
  firstChange = true;
  files: CommonFile[] = [];

  static generateID(): string {
    return Math.random().toString(16).substr(2, 8);
  }
  static updatePercentage(response: any): number {
    const { loaded, total } = response;
    if (loaded === undefined || !total) { return 0; }
    return Math.round(loaded / total * 100);
  }

  constructor(
    private request: CqUploadRequest,
    private sanitizer: DomSanitizer,
  ) {
    super();
  }
  clickHandle(): void {
    // console.log(this.elDisabled);
    if (this.elDisabled) { return; }
    this.input.nativeElement.click();
  }

  changeHandle(event: Event): void {
    // console.log(event);
    const files: FileList = ( event.target as HTMLInputElement).files;
    if (!files || !files.length) { return; }
    const checkedFiles: File[] = this.multiple ? Array.from(files) : [files[0]];
    this.input.nativeElement.value = null;

    for (const file of checkedFiles) {
      const next = {
        id: CqUploadComponent.generateID(),
        name: file.name,
        status: 'ready',
        size: file.size,
        percentage: 0,
        raw: file,
        url: this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(file))
      };
      const hasUpload = this.files.some(f => f.name === next.name);
      if (hasUpload) {
        continue;
      }
      this.files.push(next);
      this.updateFile(next);

      // amount-limit check
      // console.log('this.amountLimit', this.amountLimit)
      if (this.amountLimit > 0) {
        const successfulFiles = this.files.filter(f => f.status === 'success' || f.status === 'uploading').length;
        if (successfulFiles >= this.amountLimit) {
          this.lifecycle.error(
            Object.assign(next, { status: 'oversize', description: `Not allowed to upload more than ${this.amountLimit} files` }), files);
          continue;
        }
      }

      const filter = this.uploadFilter(file);
      const { success, description } = filter;
      if (success === false) {
        next.raw = null;
        this.lifecycle.error(Object.assign(next, { status: 'oversize', description }), files);
        // remove the oversize file if needed
        // this.removeHandle(next);
      } else {
        const beforeUpload = this.beforeUpload(file);
        if (beforeUpload) {
          this.upload(next);
        } else {
          // show mock demo
          this.uploadAnimationOnly(next);
        }
      }
    }
  }

  upload(file: CommonFile): void {
    file.status = 'uploading';
    this.updateFile(file);
    this.request.upload(this.action, file.raw)
      .subscribe((respond: any) => {
        console.log('respond', respond);
        if (respond) {
        file.percentage = CqUploadComponent.updatePercentage(respond);
        }
        file.percentage && this.lifecycle.progress(file, file.percentage);
        if (respond instanceof HttpResponse) {
          this.lifecycle.success(Object.assign(file, { status: 'success' }), respond);
        }
        this.updateFile(file);
      }, err => {
        file.status = 'failure';
        this.lifecycle.error(file, err);
        // this.removeHandle(file);
      });
  }
  uploadAnimationOnly(file: CommonFile): void {
    file.status = 'uploading';
    this.updateFile(file);
    this.request.uploadAnimation(this.action, file.raw)
      .subscribe((event: any) => {
        // console.log('event', event);
        file.percentage = CqUploadComponent.updatePercentage(event);
        file.percentage && this.lifecycle.progress(file, file.percentage);
        const { success } = event;
        if (success) {
          this.lifecycle.success(Object.assign(file, { status: 'success' }), event);
        }
        this.updateFile(file);
      }, err => {
        file.status = 'failure';
        this.lifecycle.error(file, err);
        this.removeHandle(file);
      });
  }

  removeHandle(file: CommonFile): void {
    this.lifecycle.remove(file);
    const index = this.files.findIndex(({ id }) => file.id === id);
    this.files.splice(index, 1);
  }
  refreshUpload(file: CommonFile) {
    this.upload(file);
  }

  updateFile(file: CommonFile): void {
    const index = this.files.findIndex(({ id }) => file.id === id);
    if (!index) { return; }
    this.files[index] = file;
  }

  /**
   * to fix the init subscribe issue, after ngOnInit need to populate data again,
   * moniter fileList has been change or not, if been changed, should reset files
   * @param changes
   */
  ngOnChanges(changes: { [P in keyof this]?: SimpleChange } & SimpleChanges): void {
    // console.log('ngOnChanges', changes);
    if (this.firstChange && changes.fileList) {
      // console.log('changes.fileList', changes.fileList);
      const { currentValue, previousValue } = changes.fileList;
      // console.log('currentValue', currentValue, 'previousValue', previousValue);
      if (currentValue && previousValue && currentValue.length > 0) {
        if (currentValue.length > previousValue.length) {
          this.firstChange = false;
          this.files.splice(0, this.files.length);
          currentValue.forEach((file: UploadFile) => {
            this.files.push({
              id: file.id,
              name: file.name,
              status: 'success',
              raw: null, size: null,
              url: this.sanitizer.bypassSecurityTrustUrl(file.url),
            });
          });
        }
      }
    }
  }

  ngOnInit(): void {
    this.request
      .setHeader(this.headers)
      .setCredentials(this.withCredentials)
      .setFileName(this.name)
      .addExtraData(this.data);
    this.fileList.forEach((file: UploadFile) => {
      this.files.push({
        id: file.id,
        name: file.name,
        status: 'success',
        raw: null, size: null,
        url: this.sanitizer.bypassSecurityTrustUrl(file.url),
      });
    });
  }

}
